import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await api.post('/auth/logout');
    } catch (_) {}
    logout();
    navigate('/');
  };

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.brand}>🏥 Radiology Center</Link>

      <div style={styles.links}>
        <Link to="/" style={styles.link}>Home</Link>
        <Link to="/doctors" style={styles.link}>Doctors</Link>

        {user ? (
          <>
            <span style={styles.role}>{user.role}</span>
            <Link to={`/doctor-profile`} style={styles.link}>Profile</Link>
            <button onClick={handleLogout} style={styles.btn}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.registerBtn}>Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '0 2rem', height: '60px',
    background: '#185FA5', color: '#fff',
  },
  brand: {
    color: '#fff', textDecoration: 'none', fontSize: '18px', fontWeight: '500',
  },
  links: { display: 'flex', alignItems: 'center', gap: '20px' },
  link: { color: '#B5D4F4', textDecoration: 'none', fontSize: '14px' },
  role: {
    fontSize: '11px', background: '#0C447C', color: '#B5D4F4',
    padding: '2px 8px', borderRadius: '4px',
  },
  btn: {
    background: 'transparent', border: '1px solid #B5D4F4',
    color: '#B5D4F4', padding: '4px 12px', borderRadius: '4px',
    cursor: 'pointer', fontSize: '13px',
  },
  registerBtn: {
    background: '#fff', color: '#185FA5', padding: '4px 14px',
    borderRadius: '4px', textDecoration: 'none', fontSize: '13px', fontWeight: '500',
  },
};
