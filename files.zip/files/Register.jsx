import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '', role: 'patient' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) {
      return setError('Passwords do not match.');
    }
    if (form.password.length < 6) {
      return setError('Password must be at least 6 characters.');
    }
    setLoading(true);
    try {
      const res = await api.post('/auth/register', {
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
      });
      login(res.data.user, res.data.token);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>Create Account</h2>
        <p style={styles.sub}>Join Radiology Center</p>

        {error && <div style={styles.error}>{error}</div>}

        <form onSubmit={handleSubmit}>
          <label style={styles.label}>Full Name</label>
          <input style={styles.input} type="text" name="name" placeholder="Dr. Ahmed Hassan"
            value={form.name} onChange={handleChange} required />

          <label style={styles.label}>Email</label>
          <input style={styles.input} type="email" name="email" placeholder="you@example.com"
            value={form.email} onChange={handleChange} required />

          <label style={styles.label}>I am a</label>
          <select style={styles.input} name="role" value={form.role} onChange={handleChange}>
            <option value="patient">Patient</option>
            <option value="doctor">Doctor</option>
            <option value="nurse">Nurse</option>
          </select>

          <label style={styles.label}>Password</label>
          <input style={styles.input} type="password" name="password" placeholder="Min 6 characters"
            value={form.password} onChange={handleChange} required />

          <label style={styles.label}>Confirm Password</label>
          <input style={styles.input} type="password" name="confirm" placeholder="Repeat password"
            value={form.confirm} onChange={handleChange} required />

          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? 'Creating account...' : 'Register'}
          </button>
        </form>

        <p style={styles.footer}>
          Already have an account? <Link to="/login" style={styles.link}>Login</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: 'calc(100vh - 60px)', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: '#F1EFE8', padding: '2rem',
  },
  card: {
    background: '#fff', borderRadius: '12px',
    border: '0.5px solid #D3D1C7', padding: '2rem',
    width: '100%', maxWidth: '420px',
  },
  title: { fontSize: '22px', fontWeight: '500', color: '#0C447C', margin: '0 0 4px' },
  sub: { fontSize: '14px', color: '#888780', margin: '0 0 24px' },
  error: {
    background: '#FCEBEB', border: '0.5px solid #F09595',
    color: '#A32D2D', padding: '10px 12px', borderRadius: '8px',
    fontSize: '13px', marginBottom: '16px',
  },
  label: { display: 'block', fontSize: '13px', color: '#444441', marginBottom: '6px' },
  input: {
    display: 'block', width: '100%', padding: '10px 12px',
    border: '0.5px solid #B4B2A9', borderRadius: '8px',
    fontSize: '14px', marginBottom: '16px',
    outline: 'none', boxSizing: 'border-box', background: '#fff',
  },
  btn: {
    width: '100%', padding: '11px', background: '#185FA5',
    color: '#fff', border: 'none', borderRadius: '8px',
    fontSize: '15px', fontWeight: '500', cursor: 'pointer',
  },
  footer: { textAlign: 'center', fontSize: '13px', color: '#888780', marginTop: '20px' },
  link: { color: '#185FA5', textDecoration: 'none' },
};
