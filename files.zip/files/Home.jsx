import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function Home() {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    api.get('/doctors').then((res) => setDoctors(res.data.slice(0, 6)));
  }, []);

  return (
    <div>
      {/* Hero */}
      <section style={styles.hero}>
        <h1 style={styles.heroTitle}>Advanced Radiology Care</h1>
        <p style={styles.heroSub}>Book appointments with our expert radiologists.</p>
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
          <Link to="/register" style={styles.heroBtnPrimary}>Register Now</Link>
          <Link to="/login" style={styles.heroBtnSecondary}>Book Appointment</Link>
        </div>
      </section>

      {/* Services */}
      <section style={styles.section}>
        <h2 style={styles.sectionTitle}>Our Services</h2>
        <div style={styles.grid3}>
          {[
            { icon: '🩻', title: 'X-Ray', desc: 'Fast and accurate digital X-rays.' },
            { icon: '🧲', title: 'MRI', desc: 'High-resolution MRI imaging.' },
            { icon: '🔬', title: 'CT Scan', desc: 'Detailed CT scan diagnostics.' },
          ].map((s) => (
            <div key={s.title} style={styles.card}>
              <div style={styles.cardIcon}>{s.icon}</div>
              <h3 style={styles.cardTitle}>{s.title}</h3>
              <p style={styles.cardDesc}>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Doctors preview */}
      <section style={{ ...styles.section, background: '#F1EFE8' }}>
        <h2 style={styles.sectionTitle}>Our Doctors</h2>
        <div style={styles.grid3}>
          {doctors.map((doc) => (
            <div key={doc.id} style={styles.card}>
              <div style={styles.avatar}>{doc.name?.charAt(0)}</div>
              <h3 style={styles.cardTitle}>{doc.name}</h3>
              <p style={styles.cardDesc}>{doc.specialization || 'Radiologist'}</p>
              <p style={{ fontSize: '12px', color: '#5F5E5A' }}>{doc.department_name}</p>
              <Link to={`/doctors/${doc.id}`} style={styles.cardLink}>View Profile →</Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

const styles = {
  hero: {
    background: 'linear-gradient(135deg, #185FA5, #0C447C)',
    color: '#fff', textAlign: 'center', padding: '80px 2rem',
  },
  heroTitle: { fontSize: '36px', fontWeight: '500', margin: '0 0 12px' },
  heroSub: { fontSize: '16px', color: '#B5D4F4', margin: '0 0 28px' },
  heroBtnPrimary: {
    background: '#fff', color: '#185FA5', padding: '10px 24px',
    borderRadius: '8px', textDecoration: 'none', fontWeight: '500',
  },
  heroBtnSecondary: {
    border: '1px solid #B5D4F4', color: '#B5D4F4', padding: '10px 24px',
    borderRadius: '8px', textDecoration: 'none',
  },
  section: { padding: '60px 2rem' },
  sectionTitle: {
    fontSize: '24px', fontWeight: '500', textAlign: 'center',
    margin: '0 0 32px', color: '#0C447C',
  },
  grid3: {
    display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
    gap: '20px', maxWidth: '900px', margin: '0 auto',
  },
  card: {
    background: '#fff', border: '0.5px solid #D3D1C7',
    borderRadius: '12px', padding: '24px', textAlign: 'center',
  },
  cardIcon: { fontSize: '32px', marginBottom: '12px' },
  cardTitle: { fontSize: '16px', fontWeight: '500', margin: '0 0 8px', color: '#185FA5' },
  cardDesc: { fontSize: '13px', color: '#5F5E5A', margin: '0 0 8px' },
  avatar: {
    width: '52px', height: '52px', borderRadius: '50%',
    background: '#185FA5', color: '#fff', fontSize: '20px', fontWeight: '500',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    margin: '0 auto 12px',
  },
  cardLink: { color: '#185FA5', textDecoration: 'none', fontSize: '13px' },
};
