import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [token, setToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRequest = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post('/auth/password-reset/request', { email });
      setSent(true);
      // In dev the token is returned — in production it would be emailed
      if (res.data.dev_token) setToken(res.data.dev_token);
    } catch (err) {
      setMsg(err.response?.data?.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/password-reset/confirm', { token, newPassword });
      setMsg('Password reset successfully! You can now login.');
      setSent(false);
    } catch (err) {
      setMsg(err.response?.data?.message || 'Invalid or expired token.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>Reset Password</h2>

        {msg && <div style={styles.info}>{msg}</div>}

        {!sent ? (
          <form onSubmit={handleRequest}>
            <label style={styles.label}>Enter your email</label>
            <input style={styles.input} type="email" value={email}
              onChange={(e) => setEmail(e.target.value)} required
              placeholder="you@example.com" />
            <button style={styles.btn} type="submit" disabled={loading}>
              {loading ? 'Sending...' : 'Send Reset Link'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleReset}>
            <p style={{ fontSize: '13px', color: '#5F5E5A', marginBottom: '16px' }}>
              Enter your reset token and new password.
            </p>
            <label style={styles.label}>Reset Token</label>
            <input style={styles.input} value={token}
              onChange={(e) => setToken(e.target.value)} required placeholder="Paste token here" />

            <label style={styles.label}>New Password</label>
            <input style={styles.input} type="password" value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)} required placeholder="Min 6 characters" />

            <button style={styles.btn} type="submit" disabled={loading}>
              {loading ? 'Resetting...' : 'Reset Password'}
            </button>
          </form>
        )}

        <p style={styles.footer}>
          <Link to="/login" style={styles.link}>← Back to Login</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: 'calc(100vh - 60px)', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: '#F1EFE8', padding: '2rem',
  },
  card: {
    background: '#fff', borderRadius: '12px',
    border: '0.5px solid #D3D1C7', padding: '2rem',
    width: '100%', maxWidth: '400px',
  },
  title: { fontSize: '22px', fontWeight: '500', color: '#0C447C', margin: '0 0 20px' },
  info: {
    background: '#E6F1FB', border: '0.5px solid #85B7EB',
    color: '#0C447C', padding: '10px 12px', borderRadius: '8px',
    fontSize: '13px', marginBottom: '16px',
  },
  label: { display: 'block', fontSize: '13px', color: '#444441', marginBottom: '6px' },
  input: {
    display: 'block', width: '100%', padding: '10px 12px',
    border: '0.5px solid #B4B2A9', borderRadius: '8px',
    fontSize: '14px', marginBottom: '16px',
    outline: 'none', boxSizing: 'border-box',
  },
  btn: {
    width: '100%', padding: '11px', background: '#185FA5',
    color: '#fff', border: 'none', borderRadius: '8px',
    fontSize: '15px', fontWeight: '500', cursor: 'pointer',
  },
  footer: { textAlign: 'center', fontSize: '13px', marginTop: '20px' },
  link: { color: '#185FA5', textDecoration: 'none' },
};
