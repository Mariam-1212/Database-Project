import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function DoctorProfile() {
  const { id } = useParams();
  const { user } = useAuth();
  const [doctor, setDoctor] = useState(null);
  const [patients, setPatients] = useState([]);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const doctorId = id || 'me';

  useEffect(() => {
    const fetchDoctor = async () => {
      try {
        const res = await api.get(`/doctors/${doctorId}`);
        setDoctor(res.data);
        setForm({
          specialization: res.data.specialization || '',
          degree: res.data.degree || '',
          hours_per_week: res.data.hours_per_week || 40,
        });

        if (user?.role === 'doctor' || user?.role === 'admin') {
          const pRes = await api.get(`/doctors/${doctorId}/patients`);
          setPatients(pRes.data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchDoctor();
  }, [doctorId, user]);

  const handleSave = async () => {
    try {
      await api.put(`/doctors/${doctorId}`, form);
      setDoctor({ ...doctor, ...form });
      setEditing(false);
      setMsg('Profile updated successfully.');
      setTimeout(() => setMsg(''), 3000);
    } catch (err) {
      setMsg(err.response?.data?.message || 'Update failed.');
    }
  };

  if (loading) return <div style={styles.center}>Loading...</div>;
  if (!doctor) return <div style={styles.center}>Doctor not found.</div>;

  return (
    <div style={styles.page}>
      {/* Profile Card */}
      <div style={styles.card}>
        <div style={styles.cardHeader}>
          <div style={styles.avatar}>{doctor.name?.charAt(0)}</div>
          <div>
            <h2 style={styles.name}>{doctor.name}</h2>
            <p style={styles.spec}>{doctor.specialization || 'Radiologist'}</p>
            <span style={styles.dept}>{doctor.department_name || 'Unassigned'}</span>
          </div>
          {(user?.role === 'doctor' || user?.role === 'admin') && (
            <button style={styles.editBtn} onClick={() => setEditing(!editing)}>
              {editing ? 'Cancel' : '✏️ Edit'}
            </button>
          )}
        </div>

        {msg && <div style={styles.success}>{msg}</div>}

        {editing ? (
          <div style={styles.editForm}>
            <label style={styles.label}>Specialization</label>
            <input style={styles.input} value={form.specialization}
              onChange={(e) => setForm({ ...form, specialization: e.target.value })} />

            <label style={styles.label}>Degree</label>
            <input style={styles.input} value={form.degree}
              onChange={(e) => setForm({ ...form, degree: e.target.value })} />

            <label style={styles.label}>Hours per Week</label>
            <input style={styles.input} type="number" value={form.hours_per_week}
              onChange={(e) => setForm({ ...form, hours_per_week: e.target.value })} />

            <button style={styles.saveBtn} onClick={handleSave}>Save Changes</button>
          </div>
        ) : (
          <div style={styles.infoGrid}>
            {[
              { label: 'Email', value: doctor.email },
              { label: 'Degree', value: doctor.degree || '—' },
              { label: 'Department', value: doctor.department_name || '—' },
              { label: 'Joined', value: doctor.join_date?.split('T')[0] || '—' },
              { label: 'Hours/Week', value: doctor.hours_per_week },
              { label: 'Sex', value: doctor.sex },
            ].map((item) => (
              <div key={item.label} style={styles.infoItem}>
                <span style={styles.infoLabel}>{item.label}</span>
                <span style={styles.infoValue}>{item.value}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Patients Table */}
      {patients.length > 0 && (
        <div style={styles.card}>
          <h3 style={styles.sectionTitle}>My Patients ({patients.length})</h3>
          <table style={styles.table}>
            <thead>
              <tr>
                {['Name', 'Email', 'Patient No.', 'Sex', 'Birth Date'].map((h) => (
                  <th key={h} style={styles.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {patients.map((p) => (
                <tr key={p.id}>
                  <td style={styles.td}>{p.name}</td>
                  <td style={styles.td}>{p.email}</td>
                  <td style={styles.td}>{p.patient_number}</td>
                  <td style={styles.td}>{p.sex}</td>
                  <td style={styles.td}>{p.birth_date?.split('T')[0]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const styles = {
  page: { maxWidth: '860px', margin: '2rem auto', padding: '0 1rem', display: 'flex', flexDirection: 'column', gap: '20px' },
  card: { background: '#fff', border: '0.5px solid #D3D1C7', borderRadius: '12px', padding: '24px' },
  cardHeader: { display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px', flexWrap: 'wrap' },
  avatar: {
    width: '64px', height: '64px', borderRadius: '50%', background: '#185FA5',
    color: '#fff', fontSize: '24px', fontWeight: '500',
    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  name: { fontSize: '20px', fontWeight: '500', margin: '0 0 4px', color: '#0C447C' },
  spec: { fontSize: '14px', color: '#5F5E5A', margin: '0 0 6px' },
  dept: {
    fontSize: '12px', background: '#E6F1FB', color: '#0C447C',
    padding: '2px 8px', borderRadius: '4px',
  },
  editBtn: {
    marginLeft: 'auto', background: 'transparent', border: '0.5px solid #B4B2A9',
    padding: '6px 14px', borderRadius: '8px', cursor: 'pointer', fontSize: '13px',
  },
  success: {
    background: '#EAF3DE', border: '0.5px solid #97C459', color: '#3B6D11',
    padding: '10px 12px', borderRadius: '8px', fontSize: '13px', marginBottom: '16px',
  },
  infoGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px' },
  infoItem: { display: 'flex', flexDirection: 'column', gap: '4px' },
  infoLabel: { fontSize: '11px', color: '#888780', textTransform: 'uppercase', letterSpacing: '.4px' },
  infoValue: { fontSize: '14px', color: '#2C2C2A' },
  editForm: { display: 'flex', flexDirection: 'column', gap: '0' },
  label: { fontSize: '13px', color: '#444441', marginBottom: '6px' },
  input: {
    padding: '9px 12px', border: '0.5px solid #B4B2A9', borderRadius: '8px',
    fontSize: '14px', marginBottom: '14px', outline: 'none',
  },
  saveBtn: {
    background: '#185FA5', color: '#fff', border: 'none',
    padding: '10px 20px', borderRadius: '8px', cursor: 'pointer',
    fontSize: '14px', fontWeight: '500', alignSelf: 'flex-start',
  },
  sectionTitle: { fontSize: '16px', fontWeight: '500', color: '#0C447C', margin: '0 0 16px' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
  th: {
    textAlign: 'left', padding: '8px 12px',
    background: '#F1EFE8', color: '#5F5E5A', fontWeight: '500',
  },
  td: { padding: '10px 12px', borderBottom: '0.5px solid #D3D1C7', color: '#2C2C2A' },
  center: { textAlign: 'center', padding: '4rem', color: '#888780' },
};
