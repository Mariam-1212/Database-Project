import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post('/auth/login', form);
      login(res.data.user, res.data.token);
      // Redirect based on role
      const role = res.data.user.role;
      if (role === 'admin') navigate('/admin');
      else if (role === 'doctor') navigate('/doctor-profile');
      else navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>Welcome Back</h2>
        <p style={styles.sub}>Sign in to your account</p>

        {error && <div style={styles.error}>{error}</div>}

        <form onSubmit={handleSubmit}>
          <label style={styles.label}>Email</label>
          <input
            style={styles.input}
            type="email" name="email" placeholder="you@example.com"
            value={form.email} onChange={handleChange} required
          />

          <label style={styles.label}>Password</label>
          <input
            style={styles.input}
            type="password" name="password" placeholder="••••••••"
            value={form.password} onChange={handleChange} required
          />

          <div style={{ textAlign: 'right', marginBottom: '16px' }}>
            <Link to="/forgot-password" style={styles.forgotLink}>Forgot password?</Link>
          </div>

          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <p style={styles.footer}>
          Don't have an account? <Link to="/register" style={styles.link}>Register</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: 'calc(100vh - 60px)', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: '#F1EFE8', padding: '2rem',
  },
  card: {
    background: '#fff', borderRadius: '12px',
    border: '0.5px solid #D3D1C7', padding: '2rem',
    width: '100%', maxWidth: '400px',
  },
  title: { fontSize: '22px', fontWeight: '500', color: '#0C447C', margin: '0 0 4px' },
  sub: { fontSize: '14px', color: '#888780', margin: '0 0 24px' },
  error: {
    background: '#FCEBEB', border: '0.5px solid #F09595',
    color: '#A32D2D', padding: '10px 12px', borderRadius: '8px',
    fontSize: '13px', marginBottom: '16px',
  },
  label: { display: 'block', fontSize: '13px', color: '#444441', marginBottom: '6px' },
  input: {
    display: 'block', width: '100%', padding: '10px 12px',
    border: '0.5px solid #B4B2A9', borderRadius: '8px',
    fontSize: '14px', marginBottom: '16px',
    outline: 'none', boxSizing: 'border-box',
  },
  btn: {
    width: '100%', padding: '11px', background: '#185FA5',
    color: '#fff', border: 'none', borderRadius: '8px',
    fontSize: '15px', fontWeight: '500', cursor: 'pointer',
  },
  footer: { textAlign: 'center', fontSize: '13px', color: '#888780', marginTop: '20px' },
  link: { color: '#185FA5', textDecoration: 'none' },
  forgotLink: { color: '#185FA5', textDecoration: 'none', fontSize: '13px' },
};
