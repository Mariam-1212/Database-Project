const express = require('express');
const router = express.Router();
const db = require('../config/db');
const verifyToken = require('../middleware/auth');
const allowRoles = require('../middleware/roles');

// ─── GET /api/doctors ──────────────────────────────────────────────────────
// Public: list all doctors with their department
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT d.id, u.name, u.email, d.ssn, d.sex, d.birth_date,
             d.specialization, d.degree, d.join_date, d.hours_per_week,
             dep.name AS department_name, dep.code AS department_code
      FROM doctors d
      JOIN users u ON d.user_id = u.id
      LEFT JOIN departments dep ON d.department_id = dep.id
      ORDER BY u.name
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── GET /api/doctors/:id ─────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT d.id, u.name, u.email, d.ssn, d.sex, d.birth_date,
             d.specialization, d.degree, d.join_date, d.hours_per_week,
             dep.name AS department_name, dep.code AS department_code
      FROM doctors d
      JOIN users u ON d.user_id = u.id
      LEFT JOIN departments dep ON d.department_id = dep.id
      WHERE d.id = ?
    `, [req.params.id]);

    if (rows.length === 0) return res.status(404).json({ message: 'Doctor not found.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── POST /api/doctors ────────────────────────────────────────────────────
// Admin only: create a doctor profile for an existing user
router.post('/', verifyToken, allowRoles('admin'), async (req, res) => {
  const { user_id, ssn, sex, birth_date, specialization, degree, department_id, join_date } = req.body;

  if (!user_id || !ssn || !sex || !birth_date || !join_date) {
    return res.status(400).json({ message: 'user_id, ssn, sex, birth_date and join_date are required.' });
  }

  try {
    const [result] = await db.query(
      `INSERT INTO doctors (user_id, ssn, sex, birth_date, specialization, degree, department_id, join_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [user_id, ssn, sex, birth_date, specialization, degree, department_id, join_date]
    );
    res.status(201).json({ message: 'Doctor profile created.', id: result.insertId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Doctor already exists for this user or SSN is duplicate.' });
    }
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── PUT /api/doctors/:id ─────────────────────────────────────────────────
// Doctor can edit own profile, Admin can edit any
router.put('/:id', verifyToken, allowRoles('doctor', 'admin'), async (req, res) => {
  const { specialization, degree, department_id, hours_per_week } = req.body;

  try {
    // If role is doctor, make sure they own this profile
    if (req.user.role === 'doctor') {
      const [rows] = await db.query('SELECT id FROM doctors WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
      if (rows.length === 0) return res.status(403).json({ message: 'You can only edit your own profile.' });
    }

    await db.query(
      `UPDATE doctors SET specialization = ?, degree = ?, department_id = ?, hours_per_week = ?
       WHERE id = ?`,
      [specialization, degree, department_id, hours_per_week, req.params.id]
    );
    res.json({ message: 'Doctor profile updated.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── DELETE /api/doctors/:id ──────────────────────────────────────────────
// Admin only
router.delete('/:id', verifyToken, allowRoles('admin'), async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM doctors WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Doctor not found.' });
    res.json({ message: 'Doctor deleted.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── GET /api/doctors/:id/patients ───────────────────────────────────────
// Doctor or Admin only: list patients for a doctor
router.get('/:id/patients', verifyToken, allowRoles('doctor', 'admin'), async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT DISTINCT p.id, u.name, u.email, p.patient_number, p.sex, p.birth_date
      FROM patients p
      JOIN users u ON p.user_id = u.id
      JOIN appointments a ON a.patient_id = p.id
      WHERE a.doctor_id = ?
      ORDER BY u.name
    `, [req.params.id]);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
